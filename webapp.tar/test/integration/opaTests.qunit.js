/* global QUnit */

sap.ui.require(["zgts/zgtssplml/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
