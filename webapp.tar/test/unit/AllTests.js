sap.ui.define([
	"zgts/zgtssplml/test/unit/controller/Blkdbpaddrml.controller"
], function () {
	"use strict";
});
