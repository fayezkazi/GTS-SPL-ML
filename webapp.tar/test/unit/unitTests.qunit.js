/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"zgts/zgtssplml/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});
