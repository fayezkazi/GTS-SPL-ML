/*global QUnit*/

sap.ui.define([
	"zgts/zgtssplml/controller/Blkdbpaddrml.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Blkdbpaddrml Controller");

	QUnit.test("I should test the Blkdbpaddrml controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
