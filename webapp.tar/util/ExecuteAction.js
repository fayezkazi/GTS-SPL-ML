sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], (Controller,JSONModel,MessageToast,MessageBox) => {
    "use strict";

    return Controller.extend("zgts.zgtssplml.util.ExecuteAction", {
        onInit() {
        },
        //--Confirm Block Action
        onConfirmBlock: function (that) {
            var oView = that.getView();
            var oContext = { ActionComment: '' };
            oView.setModel(new JSONModel({
                "oPayload": oContext
            }), "oJSONModelFrg");
            //Open the Fragment
            if (!this.oDialog) {
                that.loadFragment({
                    name: "zgts.zgtssplml.fragments.ConfirmBlock"
                }).then(function (oDialog) {
                    this.oDialog = oDialog;
                    this.oDialog.open();
                }.bind(this));
            } else {
                this.oDialog.open();
            }
        },
        onFragConfirmBlock: function (oView, oModel, aSelectedItems, sPath) {
            this.oDialog.close();
            this.oDialog.destroy();
            this.oDialog = null;
            var sActionComment = oView.getModel('oJSONModelFrg').getProperty('/oPayload/ActionComment');
            return new Promise((resolve, reject) => {
                //Call The Function Import for the Action
                oModel.setDeferredGroups(["batchConfirmBlock"]);
                for (let index = 0; index < aSelectedItems.length; index++) {
                    const element = aSelectedItems[index];
                    var oUrlParams = {
                        AddressID: element.AddressID,
                        LegalRegulation: element.LegalRegulation,
                        BusinessPartner: element.BusinessPartner,
                        ActionComment: sActionComment
                    };
                    oModel.callFunction(sPath, {
                        method: "POST",
                        urlParameters: oUrlParams, //oUrlParams,
                        batchGroupId: "batchConfirmBlock",
                        changeSetId: "batchConfirmBlock",
                    });

                }

                oModel.submitChanges({
                    batchGroupId: "batchConfirmBlock", //Same as the batch group id used previously
                    success: function (oData, oResponse) {
                        if (this.isNull(oData?.__batchResponses?.[0]?.__changeResponses?.[0]?.data)) {
                            new MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                        } else {
                            MessageToast.show("Confirm Block Action Executed");
                            oModel.refresh(true);
                            resolve();
                        }
                    }.bind(this),
                    error: function (oError) {
                        MessageToast.show("Failed to Confirm the Block");
                        resolve();
                    }.bind(this)
                });
            });
        },
        //--Execute On Release Action
        onRelease: function (that) {
            var oContext = {
                CstmsCmplncBlockReleaseReason: '',
                ActionComment: ''
            };
            that.getView().setModel(new JSONModel({
                "oPayload": oContext
            }), "oJSONModelFrg");
            //Open the Fragment
            if (!this.oDialog) {
                that.loadFragment({
                    name: "zgts.zgtssplml.fragments.ReleaseBlock"
                }).then(function (oDialog) {
                    this.oDialog = oDialog;
                    this.oDialog.open();
                }.bind(this));
            } else {
                this.oDialog.open();
            }
        },

        onFragRelease: function (oView, oModel, aSelectedItems, sSelectedKey, sPath) {
            this.oDialog.close();
            this.oDialog.destroy();
            this.oDialog = null;

            var sActionComment = oView.getModel('oJSONModelFrg').getProperty('/oPayload/ActionComment');
            return new Promise((resolve, reject) => {
                if (aSelectedItems.length > 0) {
                    //Call The Function Import for the Action
                    oModel.setDeferredGroups(["batchReleaseBlock"]);
                    for (let index = 0; index < aSelectedItems.length; index++) {
                        const element = aSelectedItems[index];
                        var oUrlParams = {
                            AddressID: element.AddressID,
                            LegalRegulation: element.LegalRegulation,
                            BusinessPartner: element.BusinessPartner,
                            ActionReason: sSelectedKey,
                            ActionComment: sActionComment
                        };
                        oModel.callFunction(sPath, {
                            method: "POST",
                            urlParameters: oUrlParams, //oUrlParams,
                            batchGroupId: "batchReleaseBlock",
                            changeSetId: "batchReleaseBlock",
                        });

                    }

                    oModel.submitChanges({
                        batchGroupId: "batchReleaseBlock", //Same as the batch group id used previously
                        success: function (oData, oResponse) {
                            if (this.isNull(oData?.__batchResponses?.[0]?.__changeResponses?.[0]?.data)) {
                                MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                            } else {
                                MessageToast.show("Release Block executed successfully");
                                oModel.refresh(true);
                            }
                            resolve();
                        }.bind(this),
                        error: function (oError) {
                            MessageToast.show("Release Block Failed");
                            resolve();
                        }.bind(this)
                    });
                } else {
                    MessageToast.show("Please select at least one item.");
                    resolve();
                }
            });
        },

        //--Execute the On Hold Action
        onAdopt: function (oModel, aSelectedItems, sPath) {
            if (aSelectedItems.length > 0) {
                return new Promise((resolve, reject) => {
                    //Call The Function Import for the Action
                    oModel.setDeferredGroups(["batchAdopt"]);
                    for (let index = 0; index < aSelectedItems.length; index++) {
                        const element = aSelectedItems[index];
                        var oUrlParams = {
                            AddressID: element.AddressID,
                            LegalRegulation: element.LegalRegulation,
                            BusinessPartner: element.BusinessPartner
                        };
                        oModel.callFunction(sPath, {
                            method: "POST",
                            urlParameters: oUrlParams, //oUrlParams,
                            batchGroupId: "batchAdopt",
                            changeSetId: "batchAdopt",
                        });

                    }

                    oModel.submitChanges({
                        batchGroupId: "batchAdopt", //Same as the batch group id used previously
                        success: function (oData, oResponse) {
                            if (this.isNull(oData?.__batchResponses?.[0]?.__changeResponses?.[0]?.data)) {
                                MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                            } else {
                                MessageToast.show("Adopt Action Executed successfully");
                                oModel.refresh(true);
                                resolve();
                            }
                        }.bind(this),
                        error: function (oError) {
                            MessageToast.show("Failed to Adopt");
                            resolve();
                        }.bind(this)
                    });
                });
            } else {
                MessageToast.show("Please select at least one item.");
            }
        },
        //--execute the Forward Action
        onForward: function (that) {
            var oView = that.getView();
            var oContext = { SPLScreeningBlockProcessor: '' };
            oView.setModel(new JSONModel({
                "oPayload": oContext
            }), "oJSONModelFrg");
            //Open the Fragment
            if (!this.oDialog) {
                that.loadFragment({
                    name: "zgts.zgtssplml.fragments.ForwardProcessor"
                }).then(function (oDialog) {
                    this.oDialog = oDialog;
                    this.oDialog.open();
                }.bind(this));
            } else {
                this.oDialog.open();
            }
        },
        onFragForward: function (oView, oModel, aSelectedItems, sPath) {
            this.oDialog.close();
            this.oDialog.destroy();
            this.oDialog = null;
            //Get the Selected Processor from the Fragment
            var sProcessor = oView.getModel("oJSONModelFrg").getProperty('/oPayload/SPLScreeningBlockProcessor');
            return new Promise((resolve, reject) => {
                oModel.setDeferredGroups(["batchForward"]);
                for (let index = 0; index < aSelectedItems.length; index++) {
                    const element = aSelectedItems[index];
                    var oUrlParams = {
                        AddressID: element.AddressID,
                        LegalRegulation: element.LegalRegulation,
                        BusinessPartner: element.BusinessPartner,
                        Processor: sProcessor
                    };
                    oModel.callFunction(sPath, {
                        method: "POST",
                        urlParameters: oUrlParams, //oUrlParams,
                        batchGroupId: "batchForward",
                        changeSetId: "batchForward",
                    });

                }

                oModel.submitChanges({
                    batchGroupId: "batchForward", //Same as the batch group id used previously
                    success: function (oData, oResponse) {
                        if (this.isNull(oData?.__batchResponses?.[0]?.__changeResponses?.[0]?.data)) {
                            MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                        } else {
                            MessageToast.show("Forward Action executed successfully");
                            oModel.refresh(true);
                            resolve();
                        }
                    }.bind(this),
                    error: function (oError) {
                        MessageToast.show("Forward Failed");
                        resolve();
                    }.bind(this)
                });
            });
        },

        //--execute Set Positive Action
        onPositive: function (that) {
            var oContext = {
                CstmsCmplncBlockReleaseReason: '',
                ActionComment: ''
            };
            that.getView().setModel(new JSONModel({
                "oPayload": oContext
            }), "oJSONModelFrg");
            //Open the Fragment
            if (!this.oDialog) {
                that.loadFragment({
                    name: "zgts.zgtssplml.fragments.SetPositive"
                }).then(function (oDialog) {
                    this.oDialog = oDialog;
                    this.oDialog.open();
                }.bind(this));
            } else {
                this.oDialog.open();
            }
        },
        onFragSetPositive: function (oView, oModel, aSelectedItems, sSelectedKey, sPath) {
            this.oDialog.close();
            this.oDialog.destroy();
            this.oDialog = null;

            var sActionComment = oView.getModel('oJSONModelFrg').getProperty('/oPayload/ActionComment');
            return new Promise((resolve, reject) => {
                if (aSelectedItems.length > 0) {
                    //Call The Function Import for the Action
                    oModel.setDeferredGroups(["batchSetPositive"]);
                    for (let index = 0; index < aSelectedItems.length; index++) {
                        const element = aSelectedItems[index];
                        var oUrlParams = {
                            AddressID: element.AddressID,
                            LegalRegulation: element.LegalRegulation,
                            BusinessPartner: element.BusinessPartner,
                            ActionReason: sSelectedKey,
                            ActionComment: sActionComment
                        };
                        oModel.callFunction(sPath, {
                            method: "POST",
                            urlParameters: oUrlParams, //oUrlParams,
                            batchGroupId: "batchSetPositive",
                            changeSetId: "batchSetPositive",
                        });

                    }

                    oModel.submitChanges({
                        batchGroupId: "batchSetPositive", //Same as the batch group id used previously
                        success: function (oData, oResponse) {
                            if (this.isNull(oData?.__batchResponses?.[0]?.__changeResponses?.[0]?.data)) {
                                MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                            } else {
                                MessageToast.show("Set Positive Action executed successfully");
                                oModel.refresh(true);
                            }
                            resolve();
                        }.bind(this),
                        error: function (oError) {
                            new MessageToast.show("Set Positive Failed");
                            resolve();
                        }.bind(this)
                    });
                } else {
                    MessageToast.show("Please select at least one item.");
                    resolve();
                }
            });
        },
        // Set Negetive Action 
        onNegative: function (that) {
            var oContext = {
                ActionComment: ''
            };
            that.getView().setModel(new JSONModel({
                "oPayload": oContext
            }), "oJSONModelFrg");
            //Open the Fragment
            if (!this.oDialog) {
                that.loadFragment({
                    name: "zgts.zgtssplml.fragments.SetNegative"
                }).then(function (oDialog) {
                    this.oDialog = oDialog;
                    this.oDialog.open();
                }.bind(this));
            } else {
                this.oDialog.open();
            }
        },
        onFragSetNegative: function (oView, oModel, aSelectedItems, sPath) {
            this.oDialog.close();
            this.oDialog.destroy();
            this.oDialog = null;
            var sActionComment = oView.getModel('oJSONModelFrg').getProperty('/oPayload/ActionComment');
            return new Promise((resolve, reject) => {
                //Call The Function Import for the Action
                oModel.setDeferredGroups(["batchSetNegative"]);
                for (let index = 0; index < aSelectedItems.length; index++) {
                    const element = aSelectedItems[index];
                    var oUrlParams = {
                        AddressID: element.AddressID,
                        LegalRegulation: element.LegalRegulation,
                        BusinessPartner: element.BusinessPartner,
                        ActionComment: sActionComment
                    };
                    oModel.callFunction(sPath, {
                        method: "POST",
                        urlParameters: oUrlParams, //oUrlParams,
                        batchGroupId: "batchSetNegative",
                        changeSetId: "batchSetNegative",
                    });

                }

                oModel.submitChanges({
                    batchGroupId: "batchSetNegative", //Same as the batch group id used previously
                    success: function (oData, oResponse) {
                        if (this.isNull(oData?.__batchResponses?.[0]?.__changeResponses?.[0]?.data)) {
                            MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                        } else {
                            MessageToast.show("Set Negative Action executed successfully");
                            oModel.refresh(true);
                            resolve();
                        }
                    }.bind(this),
                    error: function (oError) {
                        MessageToast.show("Set Negative Failed");
                        resolve();
                    }.bind(this)
                });
            });
        },
        onOnHold: function (oModel, aSelectedItems, sPath) {
            return new Promise((resolve, reject) => {
                //Call The Function Import for the Action
                oModel.setDeferredGroups(["batchOnHold"]);
                for (let index = 0; index < aSelectedItems.length; index++) {
                    const element = aSelectedItems[index];
                    var oUrlParams = {
                        AddressID: element.AddressID,
                        LegalRegulation: element.LegalRegulation,
                        BusinessPartner: element.BusinessPartner
                    };
                    oModel.callFunction(sPath, {
                        method: "POST",
                        urlParameters: oUrlParams, //oUrlParams,
                        batchGroupId: "batchOnHold",
                        changeSetId: "batchOnHold",
                    });
                }

                oModel.submitChanges({
                    batchGroupId: "batchOnHold", //Same as the batch group id used previously
                    success: function (oData, oResponse) {
                        if (this.isNull(oData?.__batchResponses?.[0]?.__changeResponses?.[0]?.data)) {
                            MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                        } else {
                            MessageToast.show("Set On Hold Action executed successfully");
                            oModel.refresh(true);
                            resolve();
                        }
                    }.bind(this),
                    error: function (oError) {
                        MessageToast.show("On Hold Action Failed");
                        resolve();
                    }.bind(this)
                });
            });
        },
        onRunSPL: function (oModel, aSelectedItems, sPath) {
            return new Promise((resolve, reject) => {
                oModel.setDeferredGroups(["batchRunSPL"]);
                for (let index = 0; index < aSelectedItems.length; index++) {
                    const element = aSelectedItems[index];
                    var oUrlParams = {
                        AddressID: element.AddressID,
                        LegalRegulation: element.LegalRegulation,
                        BusinessPartner: element.BusinessPartner
                    };
                    oModel.callFunction(sPath, {
                        method: "POST",
                        urlParameters: oUrlParams, //oUrlParams,
                        batchGroupId: "batchRunSPL",
                        changeSetId: "batchRunSPL",
                    });

                }

                oModel.submitChanges({
                    batchGroupId: "batchRunSPL", //Same as the batch group id used previously
                    success: function (oData, oResponse) {
                        if (this.isNull(oData?.__batchResponses?.[0]?.__changeResponses?.[0]?.data)) {
                            MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                        } else {
                            MessageToast.show("SPL Run executed successfully");
                            oModel.refresh(true);
                            resolve();
                        }
                    }.bind(this),
                    error: function (oError) {
                        MessageToast.show("SPL Run Failed");
                        resolve();
                    }.bind(this)
                });
            });
        },

        GetMLPrediction: function (oModel, aSelectedItems, sPath) {
            return new Promise((resolve, reject) => {
                oModel.setDeferredGroups(["batchGetMLPrediction"]);
                for (let index = 0; index < aSelectedItems.length; index++) {
                    const element = aSelectedItems[index];
                    var oUrlParams = {
                        AddressID: element.AddressID,
                        LegalRegulation: element.LegalRegulation,
                        BusinessPartner: element.BusinessPartner
                    };
                    oModel.callFunction(sPath, {
                        method: "POST",
                        urlParameters: oUrlParams, //oUrlParams,
                        batchGroupId: "batchGetMLPrediction",
                        changeSetId: "batchGetMLPrediction",
                    });

                }

                oModel.submitChanges({
                    batchGroupId: "batchGetMLPrediction", //Same as the batch group id used previously
                    success: function (oData, oResponse) {
                        if (this.isNull(oData?.__batchResponses?.[0]?.__changeResponses?.[0]?.data)) {
                            MessageBox.error(JSON.parse(oData.__batchResponses[0].response.body).error.message.value);
                        } else {
                            MessageToast.show("ML Prediction Calculated successfully");
                            oModel.refresh(true);
                            resolve();
                        }
                    }.bind(this),
                    error: function (oError) {
                        MessageToast.show("ML Prediction Calculation Failed");
                        resolve();
                    }.bind(this)
                });
            });
        },

        isNull: function isNull(value) {
            return value === null || value === undefined;
        },
        onCancel: function () {
            if (this.oDialog) {
                this.oDialog.close();
                this.oDialog.destroy();
                this.oDialog = null;
            }
        },
        afterClose: function () {
            this.oDialog.destroy();
            this.oDialog = null;
        }
    })
})