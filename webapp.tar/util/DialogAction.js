sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/comp/valuehelpdialog/ValueHelpDialog",
    "sap/m/Label",
    "sap/m/Text",
    "sap/ui/table/Column"
], (Controller, ValueHelpDialog,Label,Text,Column) => {
    "use strict";

    return Controller.extend("zgts.zgtssplml.util.DialogAction", {
        onInit() {
            debugger;
        },

        onFragForwardValueHelp : function(oEvent, oView) {
            debugger;
            var oInput = oEvent.getSource(); // The Input field that triggered the event
            var oModel = oView.getModel(); // OData model
 
            // Create a Value Help Dialog
            if (!this._oValueHelpDialog) {
                this._oValueHelpDialog = new ValueHelpDialog({
                    title: "Choose Processor",
                    supportMultiselect: false, // Set to true if multiple selection is required
                    key: "UserID", // Key field from the OData entity set
                    descriptionKey: "UserDescription", // Description field from the OData entity set
                    ok: function (oEvent) {
                        var aTokens = oEvent.getParameter("tokens");
                        if (aTokens.length > 0) {
                            var sSelectedKey = aTokens[0].getKey();
                            oInput.setValue(sSelectedKey); // Set the selected value in the Input field
                        }
                        this._oValueHelpDialog.close();
                    }.bind(this),
                    cancel: function () {
                        this._oValueHelpDialog.close();
                    }.bind(this),
                    afterClose: function () {
                        this._oValueHelpDialog.destroy();
                        this._oValueHelpDialog = null;
                    }.bind(this)
                });
 
                // Bind the Value Help Dialog to the OData entity set
                this._oValueHelpDialog.setModel(oModel);
                this._oValueHelpDialog.getTableAsync().then(function (oTable) {
                    oTable.setModel(oModel);
                    oTable.bindRows({
                        path: "/C_SPLScrngBPProcessorVH", // OData entity set
                        parameters: {
                            $select: "UserID,UserDescription" // Select only the required fields
                        }
                    });
 
                    // Add columns to the table
                    if (oTable.addColumn) {
                        oTable.addColumn(new Column({
                            label: new Label({ text: "User ID" }),
                            template: new Text({ text: "{UserID}" })
                        }));
                        oTable.addColumn(new Column({
                            label: new Label({ text: "User Name" }),
                            template: new Text({ text: "{UserDescription}" })
                        }));
                    }
                });
            }
 
            // Open the Value Help Dialog
            this._oValueHelpDialog.open();
 
             
        }
    })
})    