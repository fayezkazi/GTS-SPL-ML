sap.ui.define([], function () {
    "use strict";
    return {
        formatStatus: function (status) {
            debugger;
            switch (status) {
                case "S":                    
                    return "✔ Success";
                case "F":
                    return "✖ Error";
                case "R":
                    return "✔ Ready";
                default:
                    return status || "Unknown";
            }
        },
        formatTextColor: function (status) {
            debugger;
            switch (status) {
                case "S":
                    return "successText"; // Green for success
                case "F":
                    return "errorText"; // Red for error
                case "W":
                    return "warningText"; // Orange for warnings
                default:
                    return "defaultText"; // Default color
            }
        },
        formatIndirectBlock: function (status) {
            debugger;
            switch (status) {
                case true:                    
                    return "Yes";
                case false:
                    return "No";
                default:
                    return status || "Unknown";
            }
        }, 
        formatFormattedText: function (sText) {
            if(!sText) {
                return '';
            } else {
                return "<span style='font-size: 12px;'>"+sText+"</span>";
            }
            //return sStatusText;
        },  
        formatBoldBlueLink: function(sValue) {
            if (!sValue) return "";
            // Replace '#' with your desired link URL if needed
            return "<span style='font-size: 10px; color:blue; font-weight:bold; text-decoration:underline;'>" + 
                   sValue + 
                   "</span>";
        },                    
    };
});