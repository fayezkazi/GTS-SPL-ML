sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast",
    "zgts/zgtssplml/util/ExecuteAction",
    "zgts/zgtssplml/util/DialogAction",
    "../util/formatter"
],
    function (Controller, JSONModel, Filter, FilterOperator, MessageToast, ExecuteAction, DialogAction, formatter) {
        "use strict";

        return Controller.extend("zgts.zgtssplml.controller.SPLBlkdAddrDetail", {
            formatter: formatter,
            onInit: function () {
                if (!this.ExecuteAction) {
                    this.ExecuteAction = new ExecuteAction();
                }
                // Receive the selected items from the router
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.attachRouteMatched(this._onRouteMatched, this);
                oRouter.getRoute("RouteSPLBlkdAddrDetail").attachPatternMatched(this._onObjectMatched, this);
            },
            _onRouteMatched: function (oEvent) {
                var sRouteName = oEvent.getParameter("name");
                if (sRouteName === "RouteSplhits") {
                    // User is leaving the Detail view, do cleanup
                    var oModel = this.getView().getModel("oJSONModel");
                    if (oModel) {
                        oModel.setData({});
                    }
                    var oModelHdr = this.getView().getModel("oJSONModelHdr");
                    if (oModelHdr) {
                        oModelHdr.setData({});
                    }
                }
            },
            _onObjectMatched: function (oEvent) {
                // Get the selected items from the route parameters
                var sSelectedItems = oEvent.getParameter("arguments");
                if (sSelectedItems) {
                    // Now Call the service to get the data for the selected items
                    var oView = this.getView();
                    var oJSONModel = new JSONModel();
                    var oModel = this.getView().getModel();
                    // Create a filter for each selected item
                    var sPath1 = "/ZZSPLBlkdAddrHdrSet(AddressID='" + sSelectedItems.AddressID + "',LegalRegulation='" + sSelectedItems.LegalRegulation + "',BusinessPartner='" + sSelectedItems.BusinessPartner + "')";
                    var sPath2 = "/ZZSPLBlkdAddrDetailSet";
                    var aFilter = new Array();
                    var filter = new Filter({
                        path: "AddressID",
                        operator: FilterOperator.EQ,
                        value1: sSelectedItems.AddressID
                    });
                    aFilter.push(filter);
                    var filter1 = new Filter({
                        path: "LegalRegulation",
                        operator: FilterOperator.EQ,
                        value1: sSelectedItems.LegalRegulation
                    });
                    aFilter.push(filter1);

                    var filter2 = new Filter({
                        path: "BusinessPartner",
                        operator: FilterOperator.EQ,
                        value1: sSelectedItems.BusinessPartner
                    });
                    aFilter.push(filter2);

                    oView.setBusy(true);
                    //First Read the Blocked Partner Header 
                    oModel.read(sPath1, {
                        success: function (oData) {
                            // Set the data to the JSON model
                            var oJSONModelHdr = new JSONModel(oData);
                            oView.setModel(oJSONModelHdr, "oJSONModelHdr");
                            oView.setBusy(false);
                        }.bind(this),
                        error: function (oError) {
                            debugger;
                            // Handle error case
                            console.error("Error fetching data:", oError);
                            MessageToast.show("Error fetching data for selected items.");
                            oView.setBusy(false);
                        }.bind(this)

                    });

                    oView.setBusy(true);
                    //Seconf Read the Address Details of the SPL 
                    oModel.read(sPath2, {
                        filters: aFilter,
                        success: function (oData) {
                            // Set the data to the JSON model
                            oJSONModel.setProperty("/SPLBlkdAddrDetail", oData.results);
                            oView.setModel(oJSONModel, "oJSONModel");
                            oView.byId("idP3TableLabel").setText('SPL Address List (' + oData.results.length + ')');
                            oView.setBusy(false);
                        }.bind(this),
                        error: function (oError) {
                            // Handle error case
                            console.error("Error fetching data:", oError);
                            MessageToast.show("Error fetching data for selected items.");
                            oView.setBusy(false);
                        }.bind(this)

                    });
                }
            },
            onNavBack: function () {
                // 1. Clear JSON model data            
                var oModel = this.getView().getModel("oJSONModel");
                if (oModel) {
                    oModel.setData({});
                }

                var oModelHdr = this.getView().getModel("oJSONModelHdr");
                if (oModelHdr) {
                    oModelHdr.setData({}); // or setData({ Splhits: [] }) 
                }

                // 3. Navigate back

                var oHistory = sap.ui.core.routing.History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();
                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    // var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    // oRouter.navTo("RouteSplhits", { selectedItems: '' }, true);
                    window.history.go(-1);
                }
            },

            _ScreeningResultsRead: function (oEvent) {
                var oView = this.getView();
                var oModel = oView.getModel();
                var oContext = oView.getModel('oJSONModelHdr').getData();
                if (oContext) {
                    var sPath = "/ZZSPLBlkdAddrHdrSet(AddressID='" + oContext.AddressID + "',LegalRegulation='" + oContext.LegalRegulation + "',BusinessPartner='" + oContext.BusinessPartner + "')";
                    oModel.read(sPath, {
                        success: function (oData) {
                            // Set the data to the JSON model
                            var oJSONModelHdr = new JSONModel(oData);
                            oView.setModel(oJSONModelHdr, "oJSONModelHdr");
                            oView.bindElement("oJSONModelHdr>");
                        }.bind(this),
                        error: function (oError) {
                            // Handle error case
                            console.error("Error fetching data:", oError);
                            MessageToast.show("Error fetching data for selected items.");
                        }.bind(this)

                    });
                } else {
                    return;
                }

            },
            //--On Add Comments
            onPressComments: function (oEvent) {
                var oContext = oEvent.getSource().getModel('oJSONModelHdr').getData();
                this.getView().setModel(new JSONModel({
                    "oPayload": oContext
                }), "oJSONModelFrg");
                if (!this.oDialog) {
                    this.loadFragment({
                        name: "zgts.zgtssplml.fragments.AddComments"
                    }).then(function (oDialog) {
                        this.oDialog = oDialog;
                        this.oDialog.open();
                    }.bind(this));
                } else {
                    this.oDialog.open();
                }
            },

            onChangeComments: function (oEvent) {
                var that = this;
                var oView = this.getView();
                var sChangeComments = oView.byId('idChangeComments').getProperty('value');
                var oContext = oView.getModel('oJSONModelFrg').getProperty("/oPayload");

                this.oDialog.close();
                this.oDialog.destroy();
                this.oDialog = null;                
                //oContext.ProcessComment = sChangeComments;
                var oModel = this.getView().getModel();
                var oUrlParams = {
                    AddressID: oContext.AddressID,
                    LegalRegulation: oContext.LegalRegulation,
                    BusinessPartner: oContext.BusinessPartner,
                    ProcessComment: sChangeComments
                };
                oModel.setDeferredGroups(["batchManageComment"]);
                oModel.callFunction("/ManageComment", {
                    method: "POST",
                    urlParameters: oUrlParams,
                    batchGroupId: "batchManageComment",
                    changeSetId: "batchManageComment",
                });

                oModel.submitChanges({
                    batchGroupId: "batchManageComment", //Same as the batch group id used previously
                    success: function (oData, oResponse) {
                        that._ScreeningResultsRead(oEvent);
                    }.bind(this),
                    error: function (oError) {
                        MessageToast.show("Failed to Change Comments");
                    }.bind(this)
                });
            },

            onCancelComments: function (oEvent) {
                this.oDialog.close();
                this.oDialog.destroy();
                this.oDialog = null;
                return;
            },
            //--Format the Status Text
            formatStatusText: function (sStatusText) {
                return "<span style='font-size: 18px; font-weight: bold; color: red;'>" + sStatusText + "</span>";
            },
            formatDate: function (sDate) {
                if (!sDate) {
                    return ""; // Return empty string if no date is provided
                }
                var oDate = new Date(sDate);
                return oDate.toDateString();
            },

            //--Actions
            onOnHold: async function (oEvent) {
                var oModel = this.getView().getModel();
                var oContext = oEvent.getSource().getModel('oJSONModelHdr').getData();
                var aSelectedItems = [];
                aSelectedItems.push(oContext);
                await this.ExecuteAction.onOnHold(oModel, aSelectedItems, '/SetStatusOnHold');
                this._ScreeningResultsRead(oEvent);
            },
            onRunSPL: async function (oEvent) {
                var oModel = this.getView().getModel();
                var oContext = oEvent.getSource().getModel('oJSONModelHdr').getData();
                var aSelectedItems = [];
                aSelectedItems.push(oContext);
                await this.ExecuteAction.onRunSPL(oModel, aSelectedItems, '/PerformScreening');
                this._ScreeningResultsRead(oEvent);
            },
            onPositive: function (oEvent) {
                this.ExecuteAction.onPositive(this);
            },
            onFragSetPositive: function (oEvent) {
                var oModel = this.getView().getModel();
                var oContext = oEvent.getSource().getModel('oJSONModelHdr').getData();
                var aSelectedItems = [];
                aSelectedItems.push(oContext);
                var sSelectedKey = this.byId('idActionReason').getSelectedKey();
                this.ExecuteAction.onFragSetPositive(this.getView(), oModel, aSelectedItems, sSelectedKey, "/SetPositive");
                this._ScreeningResultsRead(oEvent);
            },

            onNegative: function (oEvent) {
                this.ExecuteAction.onNegative(this);
            },
            onFragSetNegative: function (oEvent) {
                var oModel = this.getView().getModel();
                var oContext = oEvent.getSource().getModel('oJSONModelHdr').getData();
                var aSelectedItems = [];
                aSelectedItems.push(oContext);
                this.ExecuteAction.onFragSetNegative(this.getView(), oModel, aSelectedItems, "/SetNegative");
                this._ScreeningResultsRead(oEvent);
            },
            onConfirmBlock: function (oEvent) {
                this.ExecuteAction.onConfirmBlock(this);
            },
            onFragConfirmBlock: async function (oEvent) {
                var oModel = this.getView().getModel();
                var oContext = oEvent.getSource().getModel('oJSONModelHdr').getData();
                var aSelectedItems = [];
                aSelectedItems.push(oContext);
                await this.ExecuteAction.onFragConfirmBlock(this.getView(), oModel, aSelectedItems, "/ConfirmBlock");
                this._ScreeningResultsRead(oEvent);
            },
            onReleaseBlock: function (oEvent) {
                this.ExecuteAction.onRelease(this);
            },
            onFragRelease: function (oEvent) {
                var oModel = this.getView().getModel();
                var oContext = oEvent.getSource().getModel('oJSONModelHdr').getData();
                var aSelectedItems = [];
                aSelectedItems.push(oContext);
                var sSelectedKey = this.byId('idReleaseBlockActionReason').getSelectedKey();
                this.ExecuteAction.onFragRelease(this.getView(), oModel, aSelectedItems, sSelectedKey, "/ReleaseBlock");
            },
            onAdopt: async function (oEvent) {
                var oModel = this.getView().getModel();
                var oContext = oEvent.getSource().getModel('oJSONModelHdr').getData();
                var aSelectedItems = [];
                aSelectedItems.push(oContext);
                await this.ExecuteAction.onAdopt(oModel, aSelectedItems, "/SetStatusPick");
                this._ScreeningResultsRead(oEvent);
            },
            onForward: function (oEvent) {
                this.ExecuteAction.onForward(this);
            },
            onFragForward: async function (oEvent) {
                var oModel = this.getView().getModel();
                var oContext = oEvent.getSource().getModel('oJSONModelHdr').getData();
                var aSelectedItems = [];
                aSelectedItems.push(oContext);
                await this.ExecuteAction.onFragForward(this.getView(), oModel, aSelectedItems, "/SetStatusForward");
                this._ScreeningResultsRead(oEvent);
            },
            onCancel: function (oEvent) {
                this.ExecuteAction.onCancel();
                return;
            },
            onForwardValueHelp: function (oEvent) {
                var oDialogAction = new DialogAction();
                oDialogAction.onFragForwardValueHelp(oEvent, this.getView())
            },
            afterClose: function () {
                this.oDialog.destroy();
            }
        });
    });