sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "zgts/zgtssplml/util/DialogAction",
    "zgts/zgtssplml/util/ExecuteAction",
    "../util/formatter",
    "sap/ui/model/json/JSONModel"
],
    function (Controller, DialogAction, ExecuteAction, formatter, JSONModel) {
        "use strict";

        return Controller.extend("zgts.zgtssplml.controller.Splhits", {
            formatter: formatter,
            onInit: function () {
                if (!this.ExecuteAction) {
                    this.ExecuteAction = new ExecuteAction();
                }                
                // Receive the selected items from the router
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.attachRouteMatched(this._onRouteMatched, this); //Added
                oRouter.getRoute("RouteSplhits").attachPatternMatched(this._onObjectMatched, this);
            },
            _onRouteMatched: function (oEvent) {
                var sRouteName = oEvent.getParameter("name");
                if (sRouteName === "RouteBlkdbpaddrml") {
                    // User is leaving the Detail view, do cleanup
                    var oModel = this.getView().getModel("oJSONModel");
                    if (oModel) {
                        oModel.setData({});
                    }
                    // Reset variables as needed
                    this._aSPLFilters = null;
                }
            },
            _onObjectMatched: function (oEvent) {
                // Get the selected items from the route parameters
                var sSelectedItems = oEvent.getParameter("arguments").selectedItems;
                // Parse the JSON string to an object
                var aSelectedItems = JSON.parse(decodeURIComponent(sSelectedItems)); // Decode and parse the JSON string
                // Set the selected items to the view model or do something with them

                if (aSelectedItems && aSelectedItems.length > 0) {
                    // Now Call the service to get the data for the selected items
                    var oView = this.getView();
                    var oJSONModel = new JSONModel();
                    var oModel = this.getView().getModel(); 
                    // Create a filter for each selected item
                    var sPath = "/ZZSPLHitsDetailSet"; 
                    var aFilters = new Array();
                    for (let index = 0; index < aSelectedItems.length; index++) {
                        const element = aSelectedItems[index];
                        var filter = new sap.ui.model.Filter({
                            path: "AddressID",
                            operator: sap.ui.model.FilterOperator.EQ,
                            value1: element.AddressID 
                        });
                        aFilters.push(filter);
                        var filter1 = new sap.ui.model.Filter({
                            path: "LegalRegulation",
                            operator: sap.ui.model.FilterOperator.EQ,
                            value1: element.LegalRegulation 
                        });
                        aFilters.push(filter1);
                        var filter2 = new sap.ui.model.Filter({
                            path: "BusinessPartner",
                            operator: sap.ui.model.FilterOperator.EQ,
                            value1: element.BusinessPartner 
                        });
                        aFilters.push(filter2);
                        this._aSPLFilters = aFilters;
                    }
                    oView.setBusy(true);
                    oModel.read(sPath, {
                        filters: aFilters,
                        success: function (oData) {
                            // Check if the data is empty
                            if (!oData || !oData.results || oData.results.length === 0) {
                                console.log("No data found for the selected items.");
                                return;
                            }
                            oJSONModel.setProperty("/Splhits", oData.results);
                            oView.setModel(oJSONModel, "oJSONModel");
                            oView.byId("page2").setTitle('SPL Hits List (' + oData.results.length + ')');
                            oView.setBusy(false);
                        },
                        error: function (oError) {
                            // Handle the error response
                            console.error("Error retrieving data:", oError);
                            oView.setBusy(false);
                        }
                    });
                }
            },
            _onSPLHitsRead: function () {
                debugger;
                var oView = this.getView();
                var oModel = this.getView().getModel();
                var sPath = "/ZZSPLHitsDetailSet";
                oView.setBusy(true);
                oModel.read(sPath, {
                    filters: this._aSPLFilters,
                    success: function (oData) {
                        var oJSONModel = new sap.ui.model.json.JSONModel();
                        oJSONModel.setProperty("/Splhits", oData.results);
                        oView.setModel(oJSONModel, "oJSONModel");
                        oView.setBusy(false);
                    },
                    error: function (oError) {
                        // Handle the error response
                        console.error("Error retrieving data:", oError);
                        oView.setBusy(false);
                    }
                });
            },            
            // onAfterRendering: function () {
            //     debugger;
            //     var oSmartTable = this.byId("idSPLHitsTable");
            //     var oTable = oSmartTable.getTable();

            //     // Use a robust polling approach to ensure columns are available
            //     var iTries = 0;
            //     var maxTries = 10;
            //     var hideFilterColumn = function () {
            //         debugger;
            //         var aColumns = oTable.getColumns();
            //         var bFound = false;
            //         aColumns.forEach(function (oCol) {
            //             if (oCol.getSortProperty && oCol.getSortProperty() === "BusinessPartner") {
            //                 debugger;
            //                 //oCol.setProperty("ignoreFromPersonalisation", true);
            //                 oCol.setProperty("filterProperty", null);
            //                 bFound = true;
            //             }
            //             if (oCol.getSortProperty && oCol.getSortProperty() === "AddressID") {
            //                 debugger;
            //                 //oCol.setProperty("ignoreFromPersonalisation", true);
            //                 oCol.setProperty("filterProperty", null);
            //                 bFound = true;
            //             }
            //             if (oCol.getSortProperty && oCol.getSortProperty() === "LegalRegulation") {
            //                 debugger;
            //                 //oCol.setProperty("ignoreFromPersonalisation", true);
            //                 oCol.setProperty("filterProperty", null);
            //                 bFound = true;
            //             }
            //         });
            //         if (!bFound && iTries < maxTries) {
            //             iTries++;
            //             setTimeout(hideFilterColumn, 200); // Try again after 200ms
            //         }
            //     };
            //     hideFilterColumn();
            // },

            onOpenMultiSortDialog: function () {
                var that = this;                
                var oTable = that.getView().byId("idSPLHitsTable");
                var oTableColumns = oTable.getColumns();
                var aColumns = oTableColumns.map( function(oColumn){
                    return {
                        key : oColumn.getSortProperty(),
                        text: oColumn.getLabel().getText()
                    }
                })

                // Helper to create a sort row
                function createSortRow() {
                    var oColumnSelect = new sap.m.Select({
                        width: "12rem",
                        items: aColumns.map(function (col) {
                            return new sap.ui.core.Item({ key: col.key, text: col.text });
                        }),
                        selectedKey: aColumns[0].key
                    });

                    var oOrderSelect = new sap.m.Select({
                        width: "8rem",
                        items: [
                            new sap.ui.core.Item({ key: "asc", text: "Ascending" }),
                            new sap.ui.core.Item({ key: "desc", text: "Descending" })
                        ],
                        selectedKey: "asc"
                    });

                    var oRemoveBtn = new sap.m.Button({
                        icon: "sap-icon://less",
                        type: "Transparent",
                        tooltip: "Remove",
                        press: function () {
                            oHBox.destroy();
                        }
                    });

                    var oHBox = new sap.m.HBox({
                        alignItems: "Center",
                        items: [
                            oColumnSelect,
                            oOrderSelect,
                            oRemoveBtn
                        ],
                        justifyContent: "Start",
                        width: "100%",
                        styleClass: "sapUiTinyMarginBottom"
                    });
                    return oHBox;
                }

                // Create dialog only once

                if (!this._oMultiSortDialog) {
                    var oVBox = new sap.m.VBox({
                        items: [createSortRow()]
                    });

                    var oAddBtn = new sap.m.Button({
                        icon: "sap-icon://add",
                        text: "Add Sort Level",
                        type: "Transparent",

                        press: function () {
                            oVBox.addItem(createSortRow());
                        }

                    });

                    this._oMultiSortDialog = new sap.m.Dialog({
                        title: "Multi-Column Sort",
                        contentWidth: "30rem",
                        content: [
                            new sap.m.Label({ text: "Sort by columns in order of priority:" }),
                            oVBox,
                            oAddBtn
                        ],

                        beginButton: new sap.m.Button({
                            text: "Sort",
                            type: "Emphasized",
                            press: function () {
                                var aSorters = [];
                                var aUsedColumns = [];
                                oVBox.getItems().forEach(function (oHBox) {
                                    var oColumnSelect = oHBox.getItems()[0];
                                    var oOrderSelect = oHBox.getItems()[1];
                                    var sCol = oColumnSelect.getSelectedKey();
                                    var sOrd = oOrderSelect.getSelectedKey();

                                    // Prevent duplicate columns
                                    if (sCol && aUsedColumns.indexOf(sCol) === -1) {
                                        aSorters.push(new sap.ui.model.Sorter(sCol, sOrd === "desc"));
                                        aUsedColumns.push(sCol);
                                    }

                                });

                                
                                oTable.getBinding("rows").sort(aSorters);
                                that._oMultiSortDialog.close();
                            }

                        }),

                        endButton: new sap.m.Button({
                            text: "Cancel",
                            press: function () {
                                that._oMultiSortDialog.close();
                            }

                        }),

                        afterClose: function () {
                            // Reset dialog for next use
                            oVBox.removeAllItems();
                            oVBox.addItem(createSortRow());
                        }
                    });
                }

                this._oMultiSortDialog.open();
            },

            onColumnVisibilityMenuSelect: function () {
                var oTable = this.byId("idSPLHitsTable");
                var aColumns = oTable.getColumns();
             
                // Build checkbox list for columns
                var aCheckboxes = aColumns.map(function (oCol, i) {
                    return new sap.m.CheckBox({
                        text: oCol.getLabel().getText(),
                        selected: oCol.getVisible(),
                        select: function (oEvent) {
                            oCol.setVisible(oEvent.getParameter("selected"));
                        }
                    });
                });
             
                // Create dialog only once
                if (!this._oColVisDialog) {
                    this._oColVisDialog = new sap.m.Dialog({
                        title: "Show/Hide Columns",
                        content: [new sap.m.VBox({ items: aCheckboxes })],
                        beginButton: new sap.m.Button({
                            text: "OK",
                            press: function () {
                                this._oColVisDialog.close();
                            }.bind(this)
                        }),
                        afterClose: function () {
                            // Destroy dialog content to avoid duplicate checkboxes next time
                            this._oColVisDialog.destroy();
                            this._oColVisDialog = null;
                        }.bind(this)
                    });
                } else {
                    // Update checkboxes if dialog is reused
                    this._oColVisDialog.removeAllContent();
                    this._oColVisDialog.addContent(new sap.m.VBox({ items: aCheckboxes }));
                }
             
                this._oColVisDialog.open();
            },  
            
            onSettingsPress: function (oEvent) {
                var oView = this.getView();
                var oTable = oView.byId("idSPLHitsTable");
 
                // Create ViewSettingsDialog only once
                if (!this._oVSD) {
                    this._oVSD = new sap.m.ViewSettingsDialog({
                        confirm: function (oEvent) {
                            var aSorters = [];
                            // Grouping
                            var oGroupItem = oEvent.getParameter("groupItem");
                            var bGroupDescending = oEvent.getParameter("groupDescending");
                            if (oGroupItem) {
                                var sGroupKey = oGroupItem.getKey();
                                if (oGroupItem) {
                                    var sGroupKey = oGroupItem.getKey();
                                    var oGroupColumn = oTable.getColumns().find(function (oCol) {
                                        return oCol.getSortProperty() === sGroupKey;
                                    });
                                    if (oGroupColumn) {
                                        oTable.setGroupBy(oGroupColumn);
                                    }
                                } else {
                                    oTable.setGroupBy(null);
                                }                                
                                aSorters.unshift(new sap.ui.model.Sorter(
                                    sGroupKey,
                                    bGroupDescending,
                                    function (oContext) {
                                        return {
                                            key: oContext.getProperty(sGroupKey),
                                            text: sGroupKey + ": " + oContext.getProperty(sGroupKey)
                                        };
                                    }
                                ));
                           
                            } else {                                
                                // If no group item is selected, clear the grouping
                                oTable.setGroupBy(null);
                            }
                            // Apply sorters to the table binding
                            oTable.getBinding("rows").sort(aSorters);
 
                            // Filtering
                            var aFilterItems = oEvent.getParameter("filterItems");
                            var aFilters = [];
                            aFilterItems.forEach(function (oItem) {
                                aFilters.push(new sap.ui.model.Filter(
                                    oItem.getParent().getKey(),
                                    sap.ui.model.FilterOperator.EQ,
                                    oItem.getText()
                                ));
                            });
                            // Apply filters to the table binding
                            oTable.getBinding("rows").filter(aFilters);
                        }
                    });
 
                    var oDataModel = oView.getModel("oJSONModel"); 
                    var aData = oDataModel ? oDataModel.getProperty("/Splhits") : [];
                    // Example: Add sort, group, and filter items dynamically based on table columns
                    var aColumns = oTable.getColumns();
                    aColumns.forEach(function (oCol) {
                        var sKey = oCol.getSortProperty();
                        var sText = oCol.getLabel().getText();
                        if (sKey) {
                            // Collect unique values for this column
                            var aUniqueValues = [];
                            var oValueMap = {};
                            aData.forEach(function (oRow) {
                                var v = oRow[sKey];
                                if (v !== undefined && v !== null && !oValueMap[v]) {
                                    oValueMap[v] = true;
                                    aUniqueValues.push(v);
                                }
                            });
 
                            // Create filter items for each unique value
                            var aFilterItems = aUniqueValues.map(function (v) {
                                return new sap.m.ViewSettingsItem({ key: v, text: String(v) });
                            });
                            this._oVSD.addGroupItem(new sap.m.ViewSettingsItem({ key: sKey, text: sText }));
                            this._oVSD.addFilterItem(new sap.m.ViewSettingsFilterItem({
                                key: sKey,
                                text: sText,
                                items: aFilterItems
                            }));
                        }
                    }.bind(this));
                }
 
                this._oVSD.open();
            },            

            onItemPress: function (oEvent) {
                debugger;
                var iColumnIndex = oEvent.getParameter('columnIndex');
                var aColumns = this.getView().byId('idSPLHitsTable').getColumns();
                if (aColumns[iColumnIndex].getSortProperty() === 'MultiNameAddr') {
                    
                } else {
                    return;
                }
                // Get the selected item's binding context
                var iIndex = oEvent.getParameter('rowIndex');
                var oContext = oEvent.getSource().getContextByIndex(iIndex); //.getObject();
                if (oContext) {
                    // Get the data of the selected row
                    var oSelectedRowData = oContext.getObject();
                    // Example: Navigate to another view with the selected row data
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("RouteSPLBlkdAddrDetail", {
                        AddressID: oSelectedRowData.AddressID,
                        LegalRegulation: oSelectedRowData.LegalRegulation,
                        BusinessPartner: oSelectedRowData.BusinessPartner
                    });
                } else {
                    sap.m.MessageToast.show("No data found for the selected row.");
                }
            },

            onNavBack: function () {
                // 1. Clear JSON model data            
                var oModel = this.getView().getModel("oJSONModel");
                if (oModel) {
                    oModel.setData({});
                }
                // 2. Reset controller variables            
                this._aSPLFilters = null;

                // 3. Navigate back

                var oHistory = sap.ui.core.routing.History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();
                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("RouteBlkdbpaddrml", {}, true);
                }
            },
            onSelectionChange: function (oEvent) {
                var oTable = this.byId("idSPLHitsTable");
                if (oTable.getSelectedIndices().length > 0) {

                    this.getView().byId('idBtnRelease').setEnabled(true);
                    this.getView().byId('idBtnPositiveList').setEnabled(true);
                    this.getView().byId('idBtnNegativeList').setEnabled(true);
                    this.getView().byId('idBtnOnHold').setEnabled(true);
                } else {
                    this.getView().byId('idBtnRelease').setEnabled(false);
                    this.getView().byId('idBtnPositiveList').setEnabled(false);
                    this.getView().byId('idBtnNegativeList').setEnabled(false);
                    this.getView().byId('idBtnOnHold').setEnabled(false);
                }
            },

            onPressRelease: function (oEvent) {
                var oTable = this.getView().byId('idSPLHitsTable');
                if (oTable.getSelectedIndices().length === 0) {
                    new sap.m.MessageBox.alert("Please select atleast one Row");
                    return;
                }
                this.ExecuteAction.onRelease(this);
            },
            onFragRelease: async function (oEvent) {
                var oModel = this.getView().getModel();
                var oTable = this.getView().byId("idSPLHitsTable"); // Get the table 
                var aIndices = oTable.getSelectedIndices();
                //var aSelectedContexts = oTable.getSelectedContexts(); // Get selected contexts
                var aSelectedItems = [];

                // Loop through the selected contexts and retrieve the data
                for (var i = 0; i < aIndices.length; i++) {
                    var iIndex = aIndices[i];
                    var oItem = oTable.getContextByIndex(iIndex);
                    if (oItem) {
                        aSelectedItems.push(oItem.getObject()); // Get the object from the context
                    }
                }

                var aUniqueItems = Array.from(
                    new Map(
                        aSelectedItems.map(item => [
                            `${item.AddressID}-${item.LegalRegulation}-${item.BusinessPartner}`,
                            item
                        ])
                    ).values()
                );

                var sSelectedKey = this.byId('idReleaseBlockActionReason').getSelectedKey();
                await this.ExecuteAction.onFragRelease(this.getView(), oModel, aUniqueItems, sSelectedKey, "/ReleaseBlock");

                this._onSPLHitsRead();
            },
            onPressOnHold: function (oEvent) {
                var oModel = this.getView().getModel();
                var oTable = this.getView().byId("idSPLHitsTable"); // Get the table 
                var aIndices = oTable.getSelectedIndices();
                //var aSelectedContexts = oTable.getSelectedContexts(); // Get selected contexts
                var aSelectedItems = [];

                // Loop through the selected contexts and retrieve the data
                for (var i = 0; i < aIndices.length; i++) {
                    var iIndex = aIndices[i];
                    var oItem = oTable.getContextByIndex(iIndex);
                    if (oItem) {
                        aSelectedItems.push(oItem.getObject()); // Get the object from the context
                    }
                }

                var aUniqueItems = Array.from(
                    new Map(
                        aSelectedItems.map(item => [
                            `${item.AddressID}-${item.LegalRegulation}-${item.BusinessPartner}`,
                            item
                        ])
                    ).values()
                );
                this.ExecuteAction.onOnHold(oModel, aUniqueItems, '/SetStatusOnHold');

            },
            onPressPositive: function (oEvent) {
                this.ExecuteAction.onPositive(this);
            },
            onFragSetPositive: async function (oEvent) {
                var oModel = this.getView().getModel();
                var oTable = this.getView().byId("idSPLHitsTable"); // Get the table  
                var aIndices = oTable.getSelectedIndices();
                var aSelectedItems = [];

                // Loop through the selected contexts and retrieve the data
                for (var i = 0; i < aIndices.length; i++) {
                    var iIndex = aIndices[i];
                    var oItem = oTable.getContextByIndex(iIndex);
                    if (oItem) {
                        aSelectedItems.push(oItem.getObject()); // Get the object from the context
                    }
                }

                var aUniqueItems = Array.from(
                    new Map(
                        aSelectedItems.map(item => [
                            `${item.AddressID}-${item.LegalRegulation}-${item.BusinessPartner}`,
                            item
                        ])
                    ).values()
                );
                var sSelectedKey = this.byId('idActionReason').getSelectedKey();
                await this.ExecuteAction.onFragSetPositive(this.getView(), oModel, aUniqueItems, sSelectedKey, "/SetPositive");

                this._onSPLHitsRead();
            },
            onPressNegative: function (oEvent) {
                this.ExecuteAction.onNegative(this);
            },
            onFragSetNegative: async function (oEvent) {
                var oModel = this.getView().getModel();
                var oTable = this.getView().byId("idSPLHitsTable"); // Get the table                
                //var aSelectedContexts = oTable.getSelectedContexts(); // Get selected contexts
                var aIndices = oTable.getSelectedIndices();
                var aSelectedItems = [];

                // Loop through the selected contexts and retrieve the data
                for (var i = 0; i < aIndices.length; i++) {
                    var iIndex = aIndices[i];
                    var oItem = oTable.getContextByIndex(iIndex);
                    if (oItem) {
                        aSelectedItems.push(oItem.getObject()); // Get the object from the context
                    }
                }

                var aUniqueItems = Array.from(
                    new Map(
                        aSelectedItems.map(item => [
                            `${item.AddressID}-${item.LegalRegulation}-${item.BusinessPartner}`,
                            item
                        ])
                    ).values()
                );
                await this.ExecuteAction.onFragSetNegative(this.getView(), oModel, aUniqueItems, "/SetNegative");
                this._onSPLHitsRead();
            },
            onCancel: function (oEvent) {
                this.ExecuteAction.onCancel();
                return;
            },


        });
    });