sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "zgts/zgtssplml/util/DialogAction",
    "zgts/zgtssplml/util/ExecuteAction",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], (Controller,DialogAction,ExecuteAction,MessageBox,MessageToast) => {
    "use strict";
    //var DialogAction = DialogAction;
    return Controller.extend("zgts.zgtssplml.controller.Blkdbpaddrml", {
        onInit() {
            this.ExecuteAction = new ExecuteAction();
            this.byId("smartFilterBar").addStyleClass("blkdBPFilterBar");
            this.byId("idBlkdBPTable").addStyleClass("BlkdBPTable");            
            
        },
        onReview: function () {
            // Get the selected items from the table
            var oTable = this.getView().byId("idBlkdBPTable").getTable();
            var aSelectedIndices = oTable.getSelectedIndices();
            if (aSelectedIndices.length > 100) {
                MessageBox.error("Please select Maximum 100 Records.");
                return; 
            }
            var aSelectedItems = [];
            for (var i = 0; i < aSelectedIndices.length; i++) {
                var oItem = oTable.getContextByIndex(aSelectedIndices[i]);
                var oLine = oItem.getObject();
                var oContext = {
                    AddressID: oLine.AddressID,
                    LegalRegulation: oLine.LegalRegulation,
                    BusinessPartner: oLine.BusinessPartner
                }                
                aSelectedItems.push(oContext);
            }
            // Create a Navigation Target
            if (aSelectedItems.length > 0) {
                // Serialize the selected items array into a JSON string
                var sSelectedItems = JSON.stringify(aSelectedItems);
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RouteSplhits", {
                    selectedItems: encodeURIComponent(sSelectedItems) // Encode to ensure safe URL transmission
                });
                // Navigate to the ItemView with the selected items as a parameter
            } else {
                // Show a message if no items are selected
                MessageToast.show("Please select at least one item.");
            }
        },
        onConfirmBlock: function (oEvent) {
            if (this.getView().byId("idBlkdBPTable").getTable().getSelectedIndices().length > 100) {
                MessageBox.error("Please select Maximum 100 Records.");
            } else
            if (this.getView().byId("idBlkdBPTable").getTable().getSelectedIndices().length > 0) {
                this.ExecuteAction.onConfirmBlock(this);
            } else {
                MessageToast.show("Please select at least one item.");
            } 
        },
        onFragConfirmBlock: function(oEvent) {
            var oModel = this.getView().getModel();
            var oTable = this.getView().byId("idBlkdBPTable").getTable();
            // Get the selected items from the table            
            var aSelectedIndices = oTable.getSelectedIndices();
            var aSelectedItems = [];
            for (var i = 0; i < aSelectedIndices.length; i++) {
                var oItem = oTable.getContextByIndex(aSelectedIndices[i]);
                aSelectedItems.push(oItem.getObject());
            }            
            this.ExecuteAction.onFragConfirmBlock(this.getView(),oModel,aSelectedItems,"/ConfirmBlock");
        },
        onReleaseBlock: function (oEvent) {
            // Get the selected items from the table
            if (this.getView().byId("idBlkdBPTable").getTable().getSelectedIndices().length > 100) {
                MessageBox.error("Please select Maximum 100 Records.");
            } else
            if (this.getView().byId("idBlkdBPTable").getTable().getSelectedIndices().length > 0) {
                this.ExecuteAction.onRelease(this);
            } else {
                MessageToast.show("Please select at least one item.");
            }  
        },
        onFragRelease: function(oEvent) {
            var oModel = this.getView().getModel();
            var oTable = this.getView().byId("idBlkdBPTable").getTable();
            var aSelectedIndices = oTable.getSelectedIndices();
            var aSelectedItems = [];
            for (var i = 0; i < aSelectedIndices.length; i++) {
                var oItem = oTable.getContextByIndex(aSelectedIndices[i]);
                aSelectedItems.push(oItem.getObject());
            } 
            var sSelectedKey = this.byId('idReleaseBlockActionReason').getSelectedKey();           
            this.ExecuteAction.onFragRelease(this.getView(),oModel,aSelectedItems,sSelectedKey,"/ReleaseBlock");
        },        
        onPositive: function (oEvent) {
            if (this.getView().byId("idBlkdBPTable").getTable().getSelectedIndices().length > 100) {
                MessageBox.error("Please select Maximum 100 Records.");
            } else
            if (this.getView().byId("idBlkdBPTable").getTable().getSelectedIndices().length > 0) {
                this.ExecuteAction.onPositive(this);
            } else {
                MessageToast.show("Please select at least one item.");
            }            
        },
        onFragSetPositive: function(oEvent) {
            var oModel = this.getView().getModel();
            var oTable = this.getView().byId("idBlkdBPTable").getTable();
            var aSelectedIndices = oTable.getSelectedIndices();
            var aSelectedItems = [];
            for (var i = 0; i < aSelectedIndices.length; i++) {
                var oItem = oTable.getContextByIndex(aSelectedIndices[i]);
                aSelectedItems.push(oItem.getObject());
            } 
            var sSelectedKey = this.byId('idActionReason').getSelectedKey();           
            this.ExecuteAction.onFragSetPositive(this.getView(),oModel,aSelectedItems,sSelectedKey,"/SetPositive");
        },
        onNegative: function (oEvent) {
            if (this.getView().byId("idBlkdBPTable").getTable().getSelectedIndices().length > 100) {
                MessageBox.error("Please select Maximum 100 Records.");
            } else
            if (this.getView().byId("idBlkdBPTable").getTable().getSelectedIndices().length > 0) {
                this.ExecuteAction.onNegative(this);
            } else {
                MessageToast.show("Please select at least one item.");
            }            
        },

        onFragSetNegative: function(oEvent) { 
            var oView = this.getView();
            var oModel = oView.getModel();
            var oTable = oView.byId("idBlkdBPTable").getTable(); 
            var aSelectedIndices = oTable.getSelectedIndices();
            var aSelectedItems = [];
            for (var i = 0; i < aSelectedIndices.length; i++) {
                var oItem = oTable.getContextByIndex(aSelectedIndices[i]);
                aSelectedItems.push(oItem.getObject());
            }               
            this.ExecuteAction.onFragSetNegative(oView,oModel,aSelectedItems,"/SetNegative");            

        },
        onAdopt: function (oEvent) {
            var oView = this.getView();
            var oModel = oView.getModel();
            var oTable = oView.byId("idBlkdBPTable").getTable(); 
            if (oTable.getSelectedIndices().length > 100) {
                MessageBox.error("Please select Maximum 100 Records.");
            } else if (oTable.getSelectedIndices().length > 0) {
            // Get the selected items from the table            
            var aSelectedIndices = oTable.getSelectedIndices();
            var aSelectedItems = [];
            for (var i = 0; i < aSelectedIndices.length; i++) {
                var oItem = oTable.getContextByIndex(aSelectedIndices[i]);
                aSelectedItems.push(oItem.getObject());
            }                
                this.ExecuteAction.onAdopt(oModel,aSelectedItems,"/SetStatusPick");
            } else {
                MessageToast.show("Please select at least one item.");
            }                        
        },
        onForward: function (oEvent) {
            if (this.getView().byId("idBlkdBPTable").getTable().getSelectedIndices().length > 100) {
                MessageBox.error("Please select Maximum 100 Records.");
            } else if (this.getView().byId("idBlkdBPTable").getTable().getSelectedIndices().length > 0) {
                this.ExecuteAction.onForward(this);
            } else {
                MessageToast.show("Please select at least one item.");
            }
        },
        onFragForward: function (oEvent) {
            var oView = this.getView();
            var oModel = oView.getModel();
            var oTable = oView.byId("idBlkdBPTable").getTable();
            // Get the selected items from the table
            var aSelectedIndices = oTable.getSelectedIndices();
            var aSelectedItems = [];
            for (var i = 0; i < aSelectedIndices.length; i++) {
                var oItem = oTable.getContextByIndex(aSelectedIndices[i]);
                aSelectedItems.push(oItem.getObject());
            }                
            this.ExecuteAction.onFragForward(oView,oModel,aSelectedItems,"/SetStatusForward");
        },
        onOnHold: function (oEvent) {            
            var oModel = this.getView().getModel();
            var oTable = this.getView().byId("idBlkdBPTable").getTable();
            if (oTable.getSelectedIndices().length > 100) {
                MessageBox.error("Please select Maximum 100 Records.");
            } else if(oTable.getSelectedIndices().length > 0 ) {
                var aSelectedIndices = oTable.getSelectedIndices();
                var aSelectedItems = [];
                for (var i = 0; i < aSelectedIndices.length; i++) {
                    var oItem = oTable.getContextByIndex(aSelectedIndices[i]);
                    aSelectedItems.push(oItem.getObject());
                }                
                this.ExecuteAction.onOnHold(oModel,aSelectedItems,'/SetStatusOnHold');
            } else {
                MessageToast.show("Please select at least one item.");
            }                      
        },
        onRunSPL: function (oEvent) {
            var oModel = this.getView().getModel();
            var oTable = this.getView().byId("idBlkdBPTable").getTable();
            if (oTable.getSelectedIndices().length > 100) {
                MessageBox.error("Please select Maximum 100 Records.");
            } else  if (oTable.getSelectedIndices().length > 0) {
                var aSelectedIndices = oTable.getSelectedIndices();
                var aSelectedItems = [];
                for (var i = 0; i < aSelectedIndices.length; i++) {
                    var oItem = oTable.getContextByIndex(aSelectedIndices[i]);
                    aSelectedItems.push(oItem.getObject());
                }                
                this.ExecuteAction.onRunSPL(oModel, aSelectedItems,'/PerformScreening');
            } else {
                MessageToast.show("Please select at least one item.");
            }                         
        },
        onGetMLPrediction: function (oEvent) {
            // Get the selected items from the table
            var oModel = this.getView().getModel();
            var oTable = this.getView().byId("idBlkdBPTable").getTable();
            if (oTable.getSelectedIndices().length > 100) {
                MessageBox.error("Please select Maximum 100 Records.");
            } else  if (oTable.getSelectedIndices().length > 0) {
                var aSelectedIndices = oTable.getSelectedIndices();
                var aSelectedItems = [];
                for (var i = 0; i < aSelectedIndices.length; i++) {
                    var oItem = oTable.getContextByIndex(aSelectedIndices[i]);
                    aSelectedItems.push(oItem.getObject());
                }                
                this.ExecuteAction.GetMLPrediction(oModel, aSelectedItems,'/GetMLPrediction');
            } else {
                MessageToast.show("Please select at least one item.");
            }                         
        },

        onCancel : function(oEvent) {
            this.ExecuteAction.onCancel();
            return;
        },
        onSelectionChange: function (oEvent) {
            var oTable = this.byId("idBlkdBPTable");
            if (oTable.getSelectedItems().length > 0) {

                this.getView().byId('btnConfBlk').setEnabled(true);
                this.getView().byId('btnRelBlk').setEnabled(true);
                this.getView().byId('btnAddToList').setEnabled(true);
                this.getView().byId('btnSetProcessor').setEnabled(true);
                this.getView().byId('btnOnHold').setEnabled(true);
                this.getView().byId('btnRunSPL').setEnabled(true);
                this.getView().byId('btnGetMLPrediction').setEnabled(true);
                this.getView().byId('btnRev').setEnabled(true);

            } else {

                this.getView().byId('btnConfBlk').setEnabled(false);
                this.getView().byId('btnRelBlk').setEnabled(false);
                this.getView().byId('btnAddToList').setEnabled(false);
                this.getView().byId('btnSetProcessor').setEnabled(false);
                this.getView().byId('btnOnHold').setEnabled(false);
                this.getView().byId('btnRunSPL').setEnabled(false);
                this.getView().byId('btnGetMLPrediction').setEnabled(false);
                this.getView().byId('btnRev').setEnabled(false);

            }
        },
        onForwardValueHelp : function(oEvent) {
            var oDialogAction = new DialogAction();
            oDialogAction.onFragForwardValueHelp(oEvent, this.getView())
        },
        afterClose: function() {
            this.oDialog.destroy();
        }
    });
});